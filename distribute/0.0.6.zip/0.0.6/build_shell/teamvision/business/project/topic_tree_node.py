class TopicTreeNode(object):

    def __init__(self):
        self.parent = 0
        self.node = None
        self.children = list()
        self.priority = 0
        self.leaf = False