#coding=utf-8
'''
Created on 2015-10-23

@author: zhangtiande
'''

from django.db.models import Count, F
from business.project.fortesting_service import ForTestingService
from teamvision.project.models import Version,TestApplication,ProjectXmindTopic,ProjectXmindFile
from teamvision.ci.models import AutoCase
from gatesidelib.datetimehelper import DateTimeHelper
from django.db import connection


class HomeStatisticsService(object):
    '''
    classdocs
    '''

    @staticmethod
    def fortesting_count_bystatus(request):
        # project_all_fortestings = ForTestingService.get_my_fortestings(request).exclude(Status__in=[4,5])
        project_all_fortestings = TestApplication.objects.all().exclude(Status__in=[5])
        result = project_all_fortestings.values('Status').annotate(TotalCount=Count('id')).order_by('Status')
        HomeStatisticsService.project_version_counts()
        return result



    @staticmethod
    def project_version_counts():
        all_versions = Version.objects.all()
        result = all_versions.values('VProjectID').annotate(TotalCount=Count('id')).order_by('-TotalCount')
        return result[0:10]

    @staticmethod
    def issue_count_byproject(request):
        project_all_fortestings = ForTestingService.get_my_fortestings(request).exclude(Status__in=[4, 5])
        result = project_all_fortestings.values('Status').annotate(TotalCount=Count('id')).order_by('Status')
        HomeStatisticsService.project_version_counts()
        return result

    @staticmethod
    def testpoint_count_byproject(request):
        result = list()
        with connection.cursor() as cursor:
            cursor.execute('select t1.Project as id,count(t1.Project) as TotalCount from (select distinct t2.Project,t2.OriginalID from project_xmind_topic t2 where IsLeaf=1 and t2.MindFileID in (select id from project_xmind_file where FileType=1)) t1  group by t1.Project order by TotalCount desc')
            for row in cursor.fetchall():
                temp = dict()
                temp["Project"] = row[0]
                temp["TotalCount"] = row[1]
                result.append(temp)
        print(result)
        return result

    @staticmethod
    def auto_case_counts():
        all_autocases = AutoCase.objects.all().filter(IsActive=1)
        result = all_autocases.values('ProjectID').annotate(TotalCount=Count('id')).order_by('-TotalCount')
        return result[0:10]
