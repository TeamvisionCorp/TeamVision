#coding=utf-8
'''
Created on 2014-11-2

@author: Zhangtiande
'''
from gatesidelib.emailhelper import EmailHelper
from business.business_service import BusinessService
from business.common.system_config_service import SystemConfigService
import threading


class EmailService(BusinessService):
    '''
    Email Service for doraemon
    '''
    
    
    @staticmethod
    def send_email(emailconfig, emaillist, emailmessage, subject):
        email_config = SystemConfigService.get_email_config()
        emailSender = EmailHelper(email_config['Host'],email_config['User'] , email_config['Password'],
                                  email_config['Postfix'],email_config['Port'])
        message = emailSender.generatetextmessage(emailmessage, subject, ','.join(emaillist), 'html')
        if email_config['Password'].strip() !="":
            worker = threading.Thread(target=emailSender.sendemaillogin, args=(emaillist, subject, message.as_string()))
            worker.start()
        else:
            worker = threading.Thread(target=emailSender.sendmail_nologin,
                                      args=(emaillist, subject, message.as_string()))
            worker.start()