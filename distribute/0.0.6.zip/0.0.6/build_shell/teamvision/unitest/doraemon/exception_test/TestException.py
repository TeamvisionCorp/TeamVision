#coding=utf-8
'''
Created on 2016-10-28

@author: Administrator
'''

class TestException(object):
    '''
    classdocs
    '''
    
    @staticmethod
    def exception_1():
        raise Exception("fdsfdsfsd")
        